/*
 * 城市、天气相关代码
 */
let provinceValue = localStorage.getItem('province');
let cityValue = localStorage.getItem('city');
let provinceIndex = 0

window.onload = function () {
    let choosecity = document.querySelector(".choosecity")
    let choosebox = document.querySelector(".choosebox")
    let provinceSelect = document.getElementById('province');
    let citySelect = document.getElementById('city');
    let province = document.getElementById('province')
    let city = document.getElementById('city')
    let address = document.getElementById('address') || {}


    provinceList.unshift({ name: '请选择', cityList: [] });
    provinceList.forEach((province, index) => {
        let option = document.createElement('option');
        option.value = province.name;
        option.text = province.name;
        provinceSelect.appendChild(option);
        if (province.name === provinceValue) {
            provinceIndex = index;
        }
    });

    provinceSelect.onchange = function () {
        let provinceIndex = provinceSelect.selectedIndex;
        populateCity(citySelect, provinceIndex);
    };

    // 确定地址
    document.getElementById('submitcity').addEventListener('click', () => {
        localStorage.setItem('province', province.value)
        localStorage.setItem('city', city.value)
        localStorage.setItem('address', address.value)
        choosecity.style.display = 'none'
        choosebox.style.display = 'block'
        getWeather(city.value)
    })

    setTimeout(() => {
        if (provinceIndex) {
            populateCity(citySelect, provinceIndex);
            provinceSelect.value = provinceValue
        } else {
            populateCity(citySelect, 0); // 默认不选择任何城市
        }
        address.value = localStorage.getItem('address') || '';
    }, 1000);

};

// 下雨特效
function rainFunction(counter = 10) {
    let hrElement;
    for (let i = 0; i < counter; i++) {
        hrElement = document.createElement("HR");
        if (i == counter - 1) {
            hrElement.className = "thunder";
        } else {
            hrElement.style.left = Math.floor(Math.random() * window.innerWidth) + "px";
            hrElement.style.animationDuration = 0.2 + Math.random() * 0.3 + "s";
            hrElement.style.animationDelay = Math.random() * 5 + "s";
        }
        document.body.appendChild(hrElement);
    }
}

// 初始化城市选项
function populateCity(citySelect, provinceIndex) {
    citySelect.options.length = 0; // 清空现有选项
    if (provinceIndex >= 0) {
        provinceList[provinceIndex].cityList.forEach(city => {
            let option = document.createElement('option');
            option.value = city.name;
            option.text = city.name;
            citySelect.appendChild(option);
            if (cityValue == city.name) {
                citySelect.value = city.name;
            }
        });
    }
}

// 获取地理位置
function getLocation() {
    if ("geolocation" in navigator) {
        navigator.geolocation.getCurrentPosition(position => {
            const latitude = position.coords.latitude;
            const longitude = position.coords.longitude;

            // 使用逆地理编码服务获取地址信息
            fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`)
                .then(response => response.json())
                .then(data => {
                    const location = data.address.state; // 获取省份信息
                    console.log("当前用户所在省份: " + location);
                })
                .catch(error => {
                    console.error("获取位置信息失败: " + error);
                });
        }, error => {
            console.error("获取地理位置失败: " + error.message);
        });
    } else {
        console.error("浏览器不支持Geolocation API");
    }

}

// 请求API获取天气数据
function getWeather(cityName = '') {
    if (!cityName) {
        return
    }
    let weatherDom = document.getElementsByClassName('weather')[0];
    cityName = cityName.replace(/市|区/g, '');
    let url = `http://v1.yiketianqi.com/free/day?appid=77243836&appsecret=2nLkkZ3x&unescape=1&city=${cityName}`
    $.get(url, function (res) {
        // const res = {
        //     "wea": "大雨",
        //     "tem": "20",
        //     "win": "东风",
        //     "win_speed": "3-4级",
        //     "win_meter": "小于10km/h"
        // }
        console.log(res);
        // 这里的res是服务器返回的数据
        setFatesByWeather(res.wea)
        setBackgroundByWeather(res.wea)
        let imgName = `default`;
        switch (res.wea) {
            case '晴':
                imgName = 'sunny';
                break;
            case '多云':
                imgName = 'cloudy';
                break;
            case '阴':
                imgName = 'overcast';
                break;
            case '小雨':
                imgName = 'lightRain';
                break;
            case '雷阵雨':
                imgName = 'thunderShower';
                break;
            case '风':
                imgName = 'wind';
                break;
        }

        weatherDom.innerHTML = `
            <span>${cityName}</span>
            <span>${getDay()}</span>
            <img src="./public/img/${imgName}.png" alt="">
            <span>${res.tem}℃</span>
            <span>${res.win}</span>
        `
    }).fail(function (jqXHR, textStatus, errorThrown) {
        // 这里处理请求失败的情况
        console.log('GET请求失败，错误信息：' + textStatus);
    });
}

// 根据天气设置背景
function setBackgroundByWeather(wea = ''){
    let body = document.getElementsByTagName('body')[0];
    if(wea.includes('大雨')){
        rainFunction(100)
    }else if(wea.includes('中雨')){
        rainFunction(50)
    }else if(wea.includes('雨')){
        rainFunction(20)
    }
    if(wea.includes('大风')){
        body.style.backgroundImage = "url(./public/img/gale.gif)";
    }else if(wea.includes('风')){
        body.style.backgroundImage = "url(./public/img/wind.gif)";
    }
    if(wea.includes('晴')){
        body.style.backgroundImage = "url(./public/img/fine.png)";
    }
    if(wea.includes('阴')){
        body.style.backgroundImage = "url(./public/img/yin.png)";
    }
    if(wea.includes('雷')){
        body.style.backgroundImage = "url(./public/img/thundery.gif)";
    }
}

// 根据天气设置随机事件
function setFatesByWeather(wea){
    const weatherFates = []
    switch (wea) {
        case '晴':
            weatherFates.push(
                ['今天天气晴朗，外出兼职挣了$200', 200, 0],
                ['今天天气晴朗，外出游玩花费$500', -500, 0]
            )
            break;
        case '多云':
            weatherFates.push(
                ['今天天气多云，出门记得带伞，收入减少$500', -500, 0]
            )
            break;
        case '阴':
            weatherFates.push(
                ['今天天气阴沉，在家睡觉忘记工作，罚款$300', -300, 0]
            )
            break;
        case '小雨':
            weatherFates.push(
                ['今天小雨，在家睡觉忘记工作，罚款$300', -300, 0]
            )
            break;
        case '雷阵雨':
            weatherFates.push(
                ['雷阵雨，不能外出工作，收入减少$500', -500, 0]
            )
            break;
        case '风':
            weatherFates.push(
                ['今天有风，把阳台的衣物晾干，收入增加$300', 300, 0]
                ['今天有风，把阳台的私房钱吹走了，积蓄减少$100', -100, 0]
            )
            break;
    }
    weatherFates.forEach(item=>{
        new CreateFate(...item)
    })
    
}





